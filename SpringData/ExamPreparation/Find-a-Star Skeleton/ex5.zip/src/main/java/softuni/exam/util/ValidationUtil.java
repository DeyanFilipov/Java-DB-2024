package softuni.exam.util;

public interface ValidationUtil {

    <E> boolean IsValid(E e);
}
